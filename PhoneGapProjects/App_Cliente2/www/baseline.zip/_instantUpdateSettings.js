function _instantUpdateSettings() {
return {
	"baseLineGUID": "3b2236323aab422383232b214880df2c",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": true,
	"message": "Version Actualizada",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Bienvenido a MariloginsaTM"
};
}