function _instantUpdateSettings() {
return {
	"baseLineGUID": "aad77b4b4d704c8ab5a8283d11e713b6",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": true,
	"message": "Version Actualizada",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Bienvenido a MariloginsaTM"
};
}