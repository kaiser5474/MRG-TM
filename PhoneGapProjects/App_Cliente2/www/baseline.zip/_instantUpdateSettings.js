function _instantUpdateSettings() {
return {
	"baseLineGUID": "c71d2b5577794263a2d20e9f19abb772",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": true,
	"message": "Version Actualizada",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Bienvenido a MariloginsaTM"
};
}