function _instantUpdateSettings() {
return {
	"baseLineGUID": "926a7008d0254785ab6f21fa57d8b303",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Bienvenido a Mariloginsa App"
};
}