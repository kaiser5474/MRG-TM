function _instantUpdateSettings() {
return {
	"baseLineGUID": "e78dd10227024f49ab1b28a0d44eab36",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Bienvenido a Mariloginsa App"
};
}